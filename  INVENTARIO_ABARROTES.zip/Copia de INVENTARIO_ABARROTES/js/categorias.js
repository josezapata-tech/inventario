
const tablaCategorias = document.getElementById("tablaCategorias");
const formularioCategoria = document.getElementById("formCategoria");

let categoriasActuales = [];

async function cargarCategorias() {
    tablaCategorias.innerHTML = `
        <tr><td colspan="4">Cargando categorías...</td></tr>
    `;

    const { data, error } = await supabaseClient
        .from("categorias")
        .select("*")
        .order("id_categoria");

    if (error) {
        console.error("Error al cargar categorías:", error);
        tablaCategorias.innerHTML = `
            <tr><td colspan="4">No se pudieron cargar las categorías.</td></tr>
        `;
        return;
    }

    categoriasActuales = data;
    mostrarCategorias(data);

    document.getElementById("totalCategorias").textContent = data.length;
}

function mostrarCategorias(categorias) {
    if (categorias.length === 0) {
        tablaCategorias.innerHTML = `
            <tr><td colspan="4">No hay categorías registradas.</td></tr>
        `;
        return;
    }

    tablaCategorias.innerHTML = categorias.map(categoria => `
        <tr>
            <td>${categoria.id_categoria}</td>
            <td>${escapar(categoria.nombre)}</td>
            <td>${escapar(categoria.descripcion || "Sin descripción")}</td>
            <td>
                <button type="button"
                    onclick="editarCategoria(${categoria.id_categoria})">
                    Editar
                </button>

                <button type="button"
                    onclick="eliminarCategoria(${categoria.id_categoria})">
                    Eliminar
                </button>
            </td>
        </tr>
    `).join("");
}

// Registrar o actualizar categoría
formularioCategoria.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const id = document.getElementById("id_categoria").value;

    const nombre = document.getElementById("nombreCategoria").value.trim();
    const descripcion = document.getElementById("descripcionCategoria").value.trim();

    if (!nombre) {
        alert("Escribe el nombre de la categoría.");
        return;
    }

    const boton = document.getElementById("btnGuardarCategoria");
    boton.disabled = true;
    boton.textContent = "Guardando...";

    try {
        let resultado;

        if (id) {
            resultado = await supabaseClient
                .from("categorias")
                .update({ nombre, descripcion })
                .eq("id_categoria", Number(id));
        } else {
            resultado = await supabaseClient
                .from("categorias")
                .insert([{ nombre, descripcion }]);
        }

        if (resultado.error) throw resultado.error;

        alert(id
            ? "Categoría actualizada correctamente."
            : "Categoría registrada correctamente."
        );

        limpiarCategoria();
        await cargarCategorias();

    } catch (error) {
        console.error("Error:", error);
        alert("No se pudo guardar: " + error.message);
    } finally {
        boton.disabled = false;
        boton.textContent = "Guardar categoría";
    }
});

// Cargar datos en el formulario
function editarCategoria(id) {
    const categoria = categoriasActuales.find(
        elemento => elemento.id_categoria === id
    );

    if (!categoria) return;

    document.getElementById("id_categoria").value = categoria.id_categoria;
    document.getElementById("nombreCategoria").value = categoria.nombre;
    document.getElementById("descripcionCategoria").value =
        categoria.descripcion || "";

    document.getElementById("tituloFormulario").textContent =
        "Editar categoría";

    document.getElementById("btnGuardarCategoria").textContent =
        "Actualizar categoría";

    window.scrollTo({ top: 0, behavior: "smooth" });
}

// Eliminar categoría si no tiene productos relacionados
async function eliminarCategoria(id) {
    const { count, error: errorConsulta } = await supabaseClient
        .from("productos")
        .select("id_producto", { count: "exact", head: true })
        .eq("id_categoria", id);

    if (errorConsulta) {
        alert("No se pudo verificar si la categoría tiene productos.");
        console.error(errorConsulta);
        return;
    }

    if (count > 0) {
        alert("No se puede eliminar esta categoría porque tiene productos relacionados.");
        return;
    }

    if (!confirm("¿Deseas eliminar esta categoría?")) return;

    const { error } = await supabaseClient
        .from("categorias")
        .delete()
        .eq("id_categoria", id);

    if (error) {
        alert("No se pudo eliminar: " + error.message);
        return;
    }

    alert("Categoría eliminada correctamente.");
    await cargarCategorias();
}

// Limpiar formulario
function limpiarCategoria() {
    formularioCategoria.reset();

    document.getElementById("id_categoria").value = "";
    document.getElementById("tituloFormulario").textContent =
        "Registrar categoría";
    document.getElementById("btnGuardarCategoria").textContent =
        "Guardar categoría";
}

document.getElementById("btnCancelarCategoria")
    .addEventListener("click", limpiarCategoria);

// Buscador
document.getElementById("buscarCategoria")
    .addEventListener("input", (evento) => {
        const busqueda = evento.target.value.toLowerCase().trim();

        const filtradas = categoriasActuales.filter(categoria =>
            categoria.nombre.toLowerCase().includes(busqueda)
        );

        mostrarCategorias(filtradas);
    });

// Evitar interpretar texto como HTML
function escapar(texto) {
    return String(texto).replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

// Iniciar módulo
document.addEventListener("DOMContentLoaded", cargarCategorias);
