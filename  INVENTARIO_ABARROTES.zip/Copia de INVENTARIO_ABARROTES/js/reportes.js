
let graficaVentas = null;
let graficaProductos = null;

const formatoDinero = cantidad =>
    Number(cantidad || 0).toLocaleString("es-MX", {
        style: "currency",
        currency: "MXN"
    });

function obtenerFechaLocal(fecha) {
    const anio = fecha.getFullYear();
    const mes = String(fecha.getMonth() + 1).padStart(2, "0");
    const dia = String(fecha.getDate()).padStart(2, "0");

    return `${anio}-${mes}-${dia}`;
}

async function cargarReportes() {
    const inicio = document.getElementById("fechaInicio").value;
    const fin = document.getElementById("fechaFin").value;

    try {
        // 1. Obtener productos activos
        const { data: productos, error: errorProductos } =
            await supabaseClient
                .from("productos")
                .select("id_producto, nombre, stock, stock_minimo")
                .eq("activo", true);

        if (errorProductos) throw errorProductos;

        // 2. Obtener ventas
        let consultaVentas = supabaseClient
            .from("ventas")
            .select("id_venta, fecha_venta, total, metodo_pago, estado")
            .eq("estado", "completada")
            .order("fecha_venta", { ascending: false });

        if (inicio) {
            consultaVentas = consultaVentas.gte("fecha_venta", `${inicio}T00:00:00`);
        }

        if (fin) {
            const fechaSiguiente = new Date(`${fin}T00:00:00`);
            fechaSiguiente.setDate(fechaSiguiente.getDate() + 1);

            consultaVentas = consultaVentas.lt(
                "fecha_venta",
                `${obtenerFechaLocal(fechaSiguiente)}T00:00:00`
            );
        }

        const { data: ventas, error: errorVentas } = await consultaVentas;

        if (errorVentas) throw errorVentas;

        const idsVentas = ventas.map(venta => venta.id_venta);

        // 3. Obtener detalles de las ventas
        let detalles = [];

        if (idsVentas.length > 0) {
            const { data, error } = await supabaseClient
                .from("detalle_ventas")
                .select("id_venta, id_producto, cantidad, subtotal")
                .in("id_venta", idsVentas);

            if (error) throw error;
            detalles = data || [];
        }

        // 4. Calcular indicadores
        const ingresos = ventas.reduce(
            (suma, venta) => suma + Number(venta.total || 0),
            0
        );

        const productosBajo = productos.filter(
            producto => producto.stock <= producto.stock_minimo
        );

        document.getElementById("totalVentas").textContent = ventas.length;

        document.getElementById("ingresos").textContent =
            formatoDinero(ingresos);

        document.getElementById("productosActivos").textContent =
            productos.length;

        document.getElementById("stockBajo").textContent =
            productosBajo.length;

        // 5. Calcular ventas por día
        const ventasPorDia = {};

        ventas.forEach(venta => {
            const fecha = new Date(venta.fecha_venta);
            const dia = obtenerFechaLocal(fecha);

            ventasPorDia[dia] =
                (ventasPorDia[dia] || 0) + Number(venta.total || 0);
        });

        const diasOrdenados = Object.keys(ventasPorDia).sort();

        crearGraficaVentas(
            diasOrdenados,
            diasOrdenados.map(dia => ventasPorDia[dia])
        );

        // 6. Calcular productos más vendidos
        const resumenProductos = {};

        detalles.forEach(detalle => {
            const producto = productos.find(
                p => p.id_producto === detalle.id_producto
            );

            const nombre = producto
                ? producto.nombre
                : `Producto #${detalle.id_producto}`;

            if (!resumenProductos[detalle.id_producto]) {
                resumenProductos[detalle.id_producto] = {
                    nombre,
                    cantidad: 0,
                    ingresos: 0
                };
            }

            resumenProductos[detalle.id_producto].cantidad +=
                Number(detalle.cantidad || 0);

            resumenProductos[detalle.id_producto].ingresos +=
                Number(detalle.subtotal || 0);
        });

        const masVendidos = Object.values(resumenProductos)
            .sort((a, b) => b.cantidad - a.cantidad)
            .slice(0, 5);

        crearGraficaProductos(masVendidos);
        llenarTablaProductos(masVendidos);

        // 7. Mostrar últimas ventas
        llenarTablaVentas(ventas.slice(0, 10));

    } catch (error) {
        console.error("Error al cargar reportes:", error);
        alert("No fue posible cargar los reportes: " + error.message);
    }
}

// Gráfica de ventas
function crearGraficaVentas(dias, cantidades) {
    const contexto = document
        .getElementById("graficaVentas")
        .getContext("2d");

    if (graficaVentas) {
        graficaVentas.destroy();
    }

    graficaVentas = new Chart(contexto, {
        type: "line",
        data: {
            labels: dias,
            datasets: [{
                label: "Ingresos por día",
                data: cantidades,
                borderColor: "#1769aa",
                backgroundColor: "rgba(23, 105, 170, 0.15)",
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Gráfica de productos
function crearGraficaProductos(productos) {
    const contexto = document
        .getElementById("graficaProductos")
        .getContext("2d");

    if (graficaProductos) {
        graficaProductos.destroy();
    }

    graficaProductos = new Chart(contexto, {
        type: "bar",
        data: {
            labels: productos.map(p => p.nombre),
            datasets: [{
                label: "Unidades vendidas",
                data: productos.map(p => p.cantidad),
                backgroundColor: [
                    "#1769aa",
                    "#2b8a78",
                    "#e3a13b",
                    "#8b65b5",
                    "#d46b6b"
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: "y",
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Tabla de productos más vendidos
function llenarTablaProductos(productos) {
    const tabla = document.getElementById("tablaMasVendidos");

    if (productos.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="3" class="empty-message">
                    Todavía no hay productos vendidos.
                </td>
            </tr>`;
        return;
    }

    tabla.innerHTML = productos.map(producto => `
        <tr>
            <td>${producto.nombre}</td>
            <td>${producto.cantidad}</td>
            <td>${formatoDinero(producto.ingresos)}</td>
        </tr>
    `).join("");
}

// Tabla de últimas ventas
function llenarTablaVentas(ventas) {
    const tabla = document.getElementById("tablaUltimasVentas");

    if (ventas.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="4" class="empty-message">
                    No hay ventas registradas en este periodo.
                </td>
            </tr>`;
        return;
    }

    tabla.innerHTML = ventas.map(venta => `
        <tr>
            <td>#${venta.id_venta}</td>
            <td>${new Date(venta.fecha_venta).toLocaleString("es-MX")}</td>
            <td>${venta.metodo_pago || "No especificado"}</td>
            <td>${formatoDinero(venta.total)}</td>
        </tr>
    `).join("");
}

// Botón para aplicar filtros
document.getElementById("btnFiltrar").addEventListener("click", () => {
    const inicio = document.getElementById("fechaInicio").value;
    const fin = document.getElementById("fechaFin").value;

    if (inicio && fin && inicio > fin) {
        alert("La fecha inicial no puede ser posterior a la fecha final.");
        return;
    }

    cargarReportes();
});

// Limpiar filtros
document.getElementById("btnLimpiar").addEventListener("click", () => {
    document.getElementById("fechaInicio").value = "";
    document.getElementById("fechaFin").value = "";
    cargarReportes();
});

// Cargar información al abrir la página
document.addEventListener("DOMContentLoaded", cargarReportes);
