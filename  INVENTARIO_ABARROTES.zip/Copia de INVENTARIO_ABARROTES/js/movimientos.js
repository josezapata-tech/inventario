
let listaProductos = [];
let listaMovimientos = [];

const dineroMovimiento = cantidad =>
    Number(cantidad).toLocaleString("es-MX");

function escaparMovimiento(texto) {
    return String(texto ?? "").replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caracter]);
}

// Cargar productos
async function cargarProductosMovimiento() {
    const selector = document.getElementById("productoMovimiento");

    const { data, error } = await supabaseClient
        .from("productos")
        .select("id_producto, nombre, codigo, stock")
        .eq("activo", true)
        .order("nombre");

    if (error) {
        console.error(error);
        selector.innerHTML = '<option value="">Error al cargar productos</option>';
        return;
    }

    listaProductos = data || [];

    selector.innerHTML = '<option value="">Selecciona un producto</option>';

    listaProductos.forEach(producto => {
        const opcion = document.createElement("option");
        opcion.value = producto.id_producto;
        opcion.textContent =
            `${producto.nombre} | Stock: ${producto.stock}`;
        selector.appendChild(opcion);
    });

    mostrarStockActual();
}

// Mostrar existencias actuales
function mostrarStockActual() {
    const id = Number(document.getElementById("productoMovimiento").value);
    const producto = listaProductos.find(
        p => Number(p.id_producto) === id
    );

    document.getElementById("stockActual").textContent = producto
        ? `Existencias actuales: ${producto.stock} unidades`
        : "";
}

// Cambiar etiqueta según el movimiento
function actualizarEtiquetaMovimiento() {
    const tipo = document.getElementById("tipoMovimiento").value;
    const etiqueta = document.getElementById("etiquetaCantidad");
    const cantidad = document.getElementById("cantidadMovimiento");

    if (tipo === "ajuste") {
        etiqueta.textContent = "Nuevo stock físico";
        cantidad.min = "0";
        cantidad.value = "0";
    } else {
        etiqueta.textContent = "Cantidad";
        cantidad.min = "1";
        cantidad.value = "1";
    }
}

// Registrar movimiento
async function registrarMovimiento() {
    const mensaje = document.getElementById("mensajeMovimiento");
    const boton = document.getElementById("btnRegistrarMovimiento");

    mensaje.textContent = "";

    const idProducto = Number(
        document.getElementById("productoMovimiento").value
    );

    const tipo = document.getElementById("tipoMovimiento").value;
    const cantidad = Number(
        document.getElementById("cantidadMovimiento").value
    );

    const motivo = document.getElementById("motivoMovimiento")
        .value.trim();

    const producto = listaProductos.find(
        p => Number(p.id_producto) === idProducto
    );

    if (!producto) {
        mensaje.textContent = "Selecciona un producto válido.";
        return;
    }

    if (!Number.isInteger(cantidad) || cantidad < (tipo === "ajuste" ? 0 : 1)) {
        mensaje.textContent = "Ingresa una cantidad válida.";
        return;
    }

    if (!motivo) {
        mensaje.textContent = "Escribe el motivo del movimiento.";
        return;
    }

    if (tipo === "salida" && cantidad > producto.stock) {
        mensaje.textContent = "No hay suficientes existencias.";
        return;
    }

    if (tipo === "ajuste" && cantidad === producto.stock) {
        mensaje.textContent = "El nuevo stock es igual al actual.";
        return;
    }

    boton.disabled = true;
    boton.textContent = "Registrando...";

    const { data, error } = await supabaseClient.rpc(
        "registrar_movimiento",
        {
            p_id_producto: idProducto,
            p_tipo: tipo,
            p_cantidad: tipo === "ajuste" ? 1 : cantidad,
            p_motivo: motivo,
            p_stock_nuevo: tipo === "ajuste" ? cantidad : null
        }
    );

    boton.disabled = false;
    boton.textContent = "Registrar movimiento";

    if (error) {
        console.error("Error al registrar movimiento:", error);
        mensaje.textContent = "No se pudo registrar: " + error.message;
        return;
    }

    mensaje.textContent =
        `¡Movimiento registrado correctamente! Folio: ${data}`;

    document.getElementById("cantidadMovimiento").value =
        tipo === "ajuste" ? "0" : "1";

    document.getElementById("motivoMovimiento").value = "";

    await cargarProductosMovimiento();
    await cargarHistorialMovimientos();
}

// Cargar historial
async function cargarHistorialMovimientos() {
    const tabla = document.getElementById("tablaMovimientos");

    const { data, error } = await supabaseClient
        .from("movimientos_inventario")
        .select(`
            id_movimiento,
            tipo_movimiento,
            cantidad,
            motivo,
            fecha_movimiento,
            productos (
                nombre
            )
        `)
        .order("fecha_movimiento", { ascending: false })
        .limit(100);

    if (error) {
        console.error(error);
        tabla.innerHTML = `
            <tr><td colspan="6">No se pudo cargar el historial.</td></tr>
        `;
        return;
    }

    listaMovimientos = data || [];
    mostrarHistorialMovimientos();
}

// Mostrar historial y buscar
function mostrarHistorialMovimientos() {
    const tabla = document.getElementById("tablaMovimientos");
    const busqueda = document.getElementById("buscarMovimiento")
        .value.trim().toLowerCase();

    const filtrados = listaMovimientos.filter(movimiento =>
        (movimiento.productos?.nombre || "")
            .toLowerCase()
            .includes(busqueda)
    );

    if (filtrados.length === 0) {
        tabla.innerHTML = `
            <tr><td colspan="6">No hay movimientos para mostrar.</td></tr>
        `;
        return;
    }

    tabla.innerHTML = filtrados.map(movimiento => {
        const tipo = movimiento.tipo_movimiento;

        return `
            <tr>
                <td>#${movimiento.id_movimiento}</td>
                <td>${escaparMovimiento(movimiento.productos?.nombre || "Producto")}</td>
                <td class="${escaparMovimiento(tipo)}">
                    ${escaparMovimiento(tipo.toUpperCase())}
                </td>
                <td>${dineroMovimiento(movimiento.cantidad)}</td>
                <td>${escaparMovimiento(movimiento.motivo || "Sin motivo")}</td>
                <td>${new Date(movimiento.fecha_movimiento).toLocaleString("es-MX")}</td>
            </tr>
        `;
    }).join("");
}

// Eventos
document.getElementById("productoMovimiento")
    .addEventListener("change", mostrarStockActual);

document.getElementById("tipoMovimiento")
    .addEventListener("change", actualizarEtiquetaMovimiento);

document.getElementById("btnRegistrarMovimiento")
    .addEventListener("click", registrarMovimiento);

document.getElementById("buscarMovimiento")
    .addEventListener("input", mostrarHistorialMovimientos);

// Inicializar
async function iniciarMovimientos() {
    actualizarEtiquetaMovimiento();
    await cargarProductosMovimiento();
    await cargarHistorialMovimientos();
}

iniciarMovimientos();
