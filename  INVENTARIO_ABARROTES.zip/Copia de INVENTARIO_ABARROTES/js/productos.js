
const tablaProductos = document.getElementById("tablaProductos");
const formulario = document.getElementById("formProducto");
const buscador = document.getElementById("buscarProducto");

let productosActuales = [];

async function cargarCategorias() {
    const { data, error } = await supabaseClient
        .from("categorias")
        .select("id_categoria, nombre")
        .order("nombre");

    if (error) {
        console.error("Error al cargar categorías:", error);
        return;
    }

    const select = document.getElementById("categoria");

    select.innerHTML = '<option value="">Selecciona una categoría</option>';

    data.forEach(categoria => {
        select.innerHTML += `
            <option value="${categoria.id_categoria}">
                ${escapar(categoria.nombre)}
            </option>
        `;
    });
}

async function cargarProveedores() {
    const { data, error } = await supabaseClient
        .from("proveedores")
        .select("id_proveedor, nombre")
        .order("nombre");

    if (error) {
        console.error("Error al cargar proveedores:", error);
        return;
    }

    const select = document.getElementById("proveedor");

    select.innerHTML = '<option value="">Sin proveedor</option>';

    data.forEach(proveedor => {
        select.innerHTML += `
            <option value="${proveedor.id_proveedor}">
                ${escapar(proveedor.nombre)}
            </option>
        `;
    });
}

async function cargarProductos() {
    tablaProductos.innerHTML = `
        <tr><td colspan="8">Cargando productos...</td></tr>
    `;

    const { data, error } = await supabaseClient
        .from("productos")
        .select(`
            id_producto,
            codigo,
            nombre,
            precio_compra,
            precio_venta,
            stock,
            stock_minimo,
            activo,
            id_categoria,
            id_proveedor,
            categorias(nombre)
        `)
        .order("nombre");

    if (error) {
        console.error("Error al cargar productos:", error);
        tablaProductos.innerHTML = `
            <tr><td colspan="8">No se pudieron cargar los productos.</td></tr>
        `;
        return;
    }

    productosActuales = data;
    mostrarProductos(data);
    actualizarResumen(data);
}

function mostrarProductos(productos) {
    if (productos.length === 0) {
        tablaProductos.innerHTML = `
            <tr><td colspan="8">No hay productos registrados.</td></tr>
        `;
        return;
    }

    tablaProductos.innerHTML = productos.map(producto => `
        <tr>
            <td>${escapar(producto.codigo)}</td>
            <td>${escapar(producto.nombre)}</td>
            <td>${escapar(producto.categorias?.nombre || "Sin categoría")}</td>
            <td>${formatoMoneda(producto.precio_compra)}</td>
            <td>${formatoMoneda(producto.precio_venta)}</td>
            <td>${producto.stock}</td>
            <td>
                <span class="estado ${producto.stock <= producto.stock_minimo ? "bajo" : "normal"}">
                    ${producto.activo
                        ? (producto.stock <= producto.stock_minimo ? "Stock bajo" : "Disponible")
                        : "Inactivo"}
                </span>
            </td>
            <td>
                <button type="button" onclick="editarProducto(${producto.id_producto})">
                    Editar
                </button>
                <button type="button" onclick="cambiarEstado(${producto.id_producto}, ${!producto.activo})">
                    ${producto.activo ? "Desactivar" : "Activar"}
                </button>
            </td>
        </tr>
    `).join("");
}

function actualizarResumen(productos) {
    const activos = productos.filter(p => p.activo);

    document.getElementById("totalProductos").textContent = activos.length;

    document.getElementById("productosBajos").textContent =
        activos.filter(p => p.stock <= p.stock_minimo).length;
}

formulario.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const id = document.getElementById("id_producto").value;

    const producto = {
        codigo: document.getElementById("codigo").value.trim(),
        nombre: document.getElementById("nombre").value.trim(),
        id_categoria: Number(document.getElementById("categoria").value),
        id_proveedor: document.getElementById("proveedor").value
            ? Number(document.getElementById("proveedor").value)
            : null,
        precio_compra: Number(document.getElementById("precio_compra").value),
        precio_venta: Number(document.getElementById("precio_venta").value),
        stock: Number(document.getElementById("stock").value),
        stock_minimo: Number(document.getElementById("stock_minimo").value)
    };

    if (!producto.codigo || !producto.nombre ||
        !producto.id_categoria ||
        !Number.isFinite(producto.precio_compra) ||
        !Number.isFinite(producto.precio_venta) ||
        !Number.isInteger(producto.stock) ||
        !Number.isInteger(producto.stock_minimo)) {
        alert("Revisa los datos del producto.");
        return;
    }

    const boton = document.getElementById("btnGuardar");
    boton.disabled = true;
    boton.textContent = "Guardando...";

    try {
        let resultado;

        if (id) {
            resultado = await supabaseClient
                .from("productos")
                .update(producto)
                .eq("id_producto", Number(id));
        } else {
            resultado = await supabaseClient
                .from("productos")
                .insert(producto);
        }

        if (resultado.error) throw resultado.error;

        alert(id ? "Producto actualizado correctamente." : "Producto registrado correctamente.");

        limpiarFormulario();
        await cargarProductos();

    } catch (error) {
        console.error("Error al guardar:", error);
        alert("No se pudo guardar el producto: " + error.message);
    } finally {
        boton.disabled = false;
        boton.textContent = "Guardar producto";
    }
});

function editarProducto(id) {
    const producto = productosActuales.find(p => p.id_producto === id);

    if (!producto) return;

    document.getElementById("id_producto").value = producto.id_producto;
    document.getElementById("codigo").value = producto.codigo;
    document.getElementById("nombre").value = producto.nombre;
    document.getElementById("categoria").value = producto.id_categoria;
    document.getElementById("proveedor").value = producto.id_proveedor || "";
    document.getElementById("precio_compra").value = producto.precio_compra;
    document.getElementById("precio_venta").value = producto.precio_venta;
    document.getElementById("stock").value = producto.stock;
    document.getElementById("stock_minimo").value = producto.stock_minimo;

    document.getElementById("btnGuardar").textContent = "Actualizar producto";

    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function cambiarEstado(id, nuevoEstado) {
    const mensaje = nuevoEstado
        ? "¿Deseas activar este producto?"
        : "¿Deseas desactivar este producto?";

    if (!confirm(mensaje)) return;

    const { error } = await supabaseClient
        .from("productos")
        .update({ activo: nuevoEstado })
        .eq("id_producto", id);

    if (error) {
        alert("No se pudo cambiar el estado: " + error.message);
        return;
    }

    await cargarProductos();
}

function limpiarFormulario() {
    formulario.reset();
    document.getElementById("id_producto").value = "";
    document.getElementById("btnGuardar").textContent = "Guardar producto";
}

document.getElementById("btnCancelar").addEventListener("click", limpiarFormulario);

buscador.addEventListener("input", () => {
    const busqueda = buscador.value.toLowerCase().trim();

    const filtrados = productosActuales.filter(producto =>
        producto.nombre.toLowerCase().includes(busqueda) ||
        producto.codigo.toLowerCase().includes(busqueda)
    );

    mostrarProductos(filtrados);
});

function formatoMoneda(valor) {
    return Number(valor).toLocaleString("es-MX", {
        style: "currency",
        currency: "MXN"
    });
}

function escapar(texto) {
    return String(texto).replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

async function iniciarProductos() {
    await Promise.all([
        cargarCategorias(),
        cargarProveedores()
    ]);

    await cargarProductos();
}

document.addEventListener("DOMContentLoaded", iniciarProductos);
