
const tablaProveedores = document.getElementById("tablaProveedores");
const formularioProveedor = document.getElementById("formProveedor");

let proveedoresActuales = [];

async function cargarProveedores() {
    tablaProveedores.innerHTML = `
        <tr><td colspan="6">Cargando proveedores...</td></tr>
    `;

    const { data, error } = await supabaseClient
        .from("proveedores")
        .select("*")
        .order("id_proveedor");

    if (error) {
        console.error("Error al cargar proveedores:", error);
        tablaProveedores.innerHTML = `
            <tr><td colspan="6">No se pudieron cargar los proveedores.</td></tr>
        `;
        return;
    }

    proveedoresActuales = data;
    mostrarProveedores(data);

    document.getElementById("totalProveedores").textContent = data.length;
}

function mostrarProveedores(proveedores) {
    if (proveedores.length === 0) {
        tablaProveedores.innerHTML = `
            <tr><td colspan="6">No hay proveedores registrados.</td></tr>
        `;
        return;
    }

    tablaProveedores.innerHTML = proveedores.map(proveedor => `
        <tr>
            <td>${proveedor.id_proveedor}</td>
            <td>${escapar(proveedor.nombre)}</td>
            <td>${escapar(proveedor.telefono || "Sin teléfono")}</td>
            <td>${escapar(proveedor.correo || "Sin correo")}</td>
            <td>${escapar(proveedor.direccion || "Sin dirección")}</td>
            <td>
                <button type="button"
                    onclick="editarProveedor(${proveedor.id_proveedor})">
                    Editar
                </button>

                <button type="button"
                    onclick="eliminarProveedor(${proveedor.id_proveedor})">
                    Eliminar
                </button>
            </td>
        </tr>
    `).join("");
}

// Registrar o actualizar proveedor
formularioProveedor.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const id = document.getElementById("id_proveedor").value;

    const proveedor = {
        nombre: document.getElementById("nombreProveedor").value.trim(),
        telefono: document.getElementById("telefonoProveedor").value.trim() || null,
        correo: document.getElementById("correoProveedor").value.trim() || null,
        direccion: document.getElementById("direccionProveedor").value.trim() || null
    };

    if (!proveedor.nombre) {
        alert("Escribe el nombre del proveedor.");
        return;
    }

    const boton = document.getElementById("btnGuardarProveedor");
    boton.disabled = true;
    boton.textContent = "Guardando...";

    try {
        let resultado;

        if (id) {
            resultado = await supabaseClient
                .from("proveedores")
                .update(proveedor)
                .eq("id_proveedor", Number(id));
        } else {
            resultado = await supabaseClient
                .from("proveedores")
                .insert([proveedor]);
        }

        if (resultado.error) throw resultado.error;

        alert(id
            ? "Proveedor actualizado correctamente."
            : "Proveedor registrado correctamente."
        );

        limpiarProveedor();
        await cargarProveedores();

    } catch (error) {
        console.error("Error:", error);
        alert("No se pudo guardar: " + error.message);
    } finally {
        boton.disabled = false;
        boton.textContent = "Guardar proveedor";
    }
});

// Editar proveedor
function editarProveedor(id) {
    const proveedor = proveedoresActuales.find(
        elemento => elemento.id_proveedor === id
    );

    if (!proveedor) return;

    document.getElementById("id_proveedor").value = proveedor.id_proveedor;
    document.getElementById("nombreProveedor").value = proveedor.nombre;
    document.getElementById("telefonoProveedor").value = proveedor.telefono || "";
    document.getElementById("correoProveedor").value = proveedor.correo || "";
    document.getElementById("direccionProveedor").value = proveedor.direccion || "";

    document.getElementById("tituloProveedor").textContent = "Editar proveedor";
    document.getElementById("btnGuardarProveedor").textContent = "Actualizar proveedor";

    window.scrollTo({ top: 0, behavior: "smooth" });
}

// Eliminar proveedor
async function eliminarProveedor(id) {
    const { count, error: errorConsulta } = await supabaseClient
        .from("productos")
        .select("id_producto", { count: "exact", head: true })
        .eq("id_proveedor", id);

    if (errorConsulta) {
        alert("No se pudo verificar si el proveedor tiene productos asociados.");
        console.error(errorConsulta);
        return;
    }

    if (count > 0) {
        alert("No se puede eliminar este proveedor porque tiene productos asociados.");
        return;
    }

    if (!confirm("¿Deseas eliminar este proveedor?")) return;

    const { error } = await supabaseClient
        .from("proveedores")
        .delete()
        .eq("id_proveedor", id);

    if (error) {
        alert("No se pudo eliminar: " + error.message);
        return;
    }

    alert("Proveedor eliminado correctamente.");
    await cargarProveedores();
}

// Limpiar formulario
function limpiarProveedor() {
    formularioProveedor.reset();

    document.getElementById("id_proveedor").value = "";
    document.getElementById("tituloProveedor").textContent = "Registrar proveedor";
    document.getElementById("btnGuardarProveedor").textContent = "Guardar proveedor";
}

document.getElementById("btnCancelarProveedor")
    .addEventListener("click", limpiarProveedor);

// Buscador
document.getElementById("buscarProveedor")
    .addEventListener("input", (evento) => {
        const busqueda = evento.target.value.toLowerCase().trim();

        const filtrados = proveedoresActuales.filter(proveedor =>
            proveedor.nombre.toLowerCase().includes(busqueda) ||
            (proveedor.telefono || "").toLowerCase().includes(busqueda) ||
            (proveedor.correo || "").toLowerCase().includes(busqueda)
        );

        mostrarProveedores(filtrados);
    });

// Evitar interpretar texto como HTML
function escapar(texto) {
    return String(texto).replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

document.addEventListener("DOMContentLoaded", cargarProveedores);
