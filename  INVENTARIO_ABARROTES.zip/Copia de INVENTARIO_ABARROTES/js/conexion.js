
const SUPABASE_URL = "https://nnptvvwwnbprvlznreku.supabase.co";

const SUPABASE_KEY = "sb_publishable_7vP_6T4ysASGZa9PWHMvww_EZatSTem";

const supabaseClient = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);

console.log("Conexión con Supabase inicializada");