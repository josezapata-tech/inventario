
let productosDisponibles = [];
let carrito = [];

const formatoDinero = (cantidad) =>
    Number(cantidad).toLocaleString("es-MX", {
        style: "currency",
        currency: "MXN"
    });

function escaparHTML(texto) {
    return String(texto ?? "").replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caracter]);
}

// Cargar productos disponibles
async function cargarProductosVenta() {
    const selector = document.getElementById("productoVenta");

    const { data, error } = await supabaseClient
        .from("productos")
        .select("id_producto, codigo, nombre, precio_venta, stock")
        .eq("activo", true)
        .gt("stock", 0)
        .order("nombre");

    if (error) {
        selector.innerHTML = '<option value="">Error al cargar productos</option>';
        console.error(error);
        return;
    }

    productosDisponibles = data || [];

    selector.innerHTML = '<option value="">Selecciona un producto</option>';

    productosDisponibles.forEach(producto => {
        const opcion = document.createElement("option");

        opcion.value = producto.id_producto;
        opcion.textContent =
            `${producto.nombre} - ${formatoDinero(producto.precio_venta)} | Stock: ${producto.stock}`;

        selector.appendChild(opcion);
    });
}

// Agregar producto al carrito
function agregarProducto() {
    const id = Number(document.getElementById("productoVenta").value);
    const cantidad = Number(document.getElementById("cantidadVenta").value);
    const mensaje = document.getElementById("mensajeVenta");

    mensaje.textContent = "";

    if (!id) {
        mensaje.textContent = "Selecciona un producto.";
        return;
    }

    if (!Number.isInteger(cantidad) || cantidad <= 0) {
        mensaje.textContent = "Ingresa una cantidad válida.";
        return;
    }

    const producto = productosDisponibles.find(
        p => Number(p.id_producto) === id
    );

    if (!producto) {
        mensaje.textContent = "El producto no está disponible.";
        return;
    }

    const existente = carrito.find(
        p => Number(p.id_producto) === id
    );

    const cantidadFinal = cantidad + (existente ? existente.cantidad : 0);

    if (cantidadFinal > producto.stock) {
        mensaje.textContent =
            `Stock insuficiente. Solo hay ${producto.stock} unidades disponibles.`;
        return;
    }

    if (existente) {
        existente.cantidad += cantidad;
    } else {
        carrito.push({
            id_producto: producto.id_producto,
            nombre: producto.nombre,
            precio: Number(producto.precio_venta),
            cantidad: cantidad
        });
    }

    document.getElementById("cantidadVenta").value = 1;
    renderizarCarrito();
}

// Mostrar carrito
function renderizarCarrito() {
    const tabla = document.getElementById("tablaCarrito");
    let total = 0;

    if (carrito.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="5">No hay productos agregados.</td>
            </tr>
        `;
    } else {
        tabla.innerHTML = carrito.map(producto => {
            const subtotal = producto.precio * producto.cantidad;
            total += subtotal;

            return `
                <tr>
                    <td>${escaparHTML(producto.nombre)}</td>
                    <td>${formatoDinero(producto.precio)}</td>
                    <td>${producto.cantidad}</td>
                    <td>${formatoDinero(subtotal)}</td>
                    <td>
                        <button type="button"
                            class="btnEliminarProducto"
                            data-id="${producto.id_producto}">
                            Eliminar
                        </button>
                    </td>
                </tr>
            `;
        }).join("");
    }

    document.getElementById("totalVenta").textContent =
        formatoDinero(total);
}

// Eliminar producto del carrito
function eliminarProducto(id) {
    carrito = carrito.filter(
        producto => Number(producto.id_producto) !== Number(id)
    );

    renderizarCarrito();
}

// Registrar venta
async function registrarVenta() {
    const mensaje = document.getElementById("mensajeVenta");
    const boton = document.getElementById("btnRegistrarVenta");

    mensaje.textContent = "";

    if (carrito.length === 0) {
        mensaje.textContent = "Agrega al menos un producto.";
        return;
    }

    const detalles = carrito.map(producto => ({
        id_producto: producto.id_producto,
        cantidad: producto.cantidad
    }));

    const metodoPago = document.getElementById("metodoPago").value;

    boton.disabled = true;
    boton.textContent = "Registrando...";

    const { data, error } = await supabaseClient.rpc(
        "registrar_venta",
        {
            p_detalles: detalles,
            p_metodo_pago: metodoPago
        }
    );

    boton.disabled = false;
    boton.textContent = "Registrar venta";

    if (error) {
        console.error("Error al registrar venta:", error);
        mensaje.textContent = "No se pudo registrar la venta: " + error.message;
        return;
    }

    carrito = [];
    renderizarCarrito();

    mensaje.textContent = `¡Venta registrada correctamente! Folio: ${data}`;

    await cargarProductosVenta();
    await cargarHistorialVentas();
}

// Consultar historial de ventas
async function cargarHistorialVentas() {
    const tabla = document.getElementById("tablaHistorialVentas");

    const { data, error } = await supabaseClient
        .from("ventas")
        .select("id_venta, fecha_venta, metodo_pago, total, estado")
        .order("fecha_venta", { ascending: false })
        .limit(30);

    if (error) {
        console.error(error);
        tabla.innerHTML = `
            <tr>
                <td colspan="5">No se pudo cargar el historial.</td>
            </tr>
        `;
        return;
    }

    if (!data || data.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="5">Todavía no hay ventas registradas.</td>
            </tr>
        `;
        return;
    }

    tabla.innerHTML = data.map(venta => `
        <tr>
            <td>#${venta.id_venta}</td>
            <td>${new Date(venta.fecha_venta).toLocaleString("es-MX")}</td>
            <td>${escaparHTML(venta.metodo_pago || "No especificado")}</td>
            <td>${formatoDinero(venta.total)}</td>
            <td>${escaparHTML(venta.estado)}</td>
        </tr>
    `).join("");
}

// Eventos de la página
document.getElementById("btnAgregarProducto")
    .addEventListener("click", agregarProducto);

document.getElementById("btnRegistrarVenta")
    .addEventListener("click", registrarVenta);

document.getElementById("btnLimpiarVenta")
    .addEventListener("click", () => {
        carrito = [];
        renderizarCarrito();
        document.getElementById("mensajeVenta").textContent = "";
    });

document.getElementById("tablaCarrito")
    .addEventListener("click", evento => {
        const boton = evento.target.closest(".btnEliminarProducto");

        if (boton) {
            eliminarProducto(boton.dataset.id);
        }
    });

// Inicializar página
async function iniciarVentas() {
    await cargarProductosVenta();
    renderizarCarrito();
    await cargarHistorialVentas();
}

iniciarVentas();
