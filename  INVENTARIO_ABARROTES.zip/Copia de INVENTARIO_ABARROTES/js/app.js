
async function cargarDashboard() {
    const tabla = document.getElementById("tablaStock");

    try {
        // Consultar total de productos
        const productos = await supabaseClient
            .from("productos")
            .select("*", { count: "exact", head: true });

        // Consultar total de categorías
        const categorias = await supabaseClient
            .from("categorias")
            .select("*", { count: "exact", head: true });

        // Consultar total de ventas
        const ventas = await supabaseClient
            .from("ventas")
            .select("*", { count: "exact", head: true });

        // Consultar productos registrados
        const listaProductos = await supabaseClient
            .from("productos")
            .select("codigo, nombre, stock, stock_minimo")
            .eq("activo", true)
            .order("nombre");

        if (productos.error) throw productos.error;
        if (categorias.error) throw categorias.error;
        if (ventas.error) throw ventas.error;
        if (listaProductos.error) throw listaProductos.error;

        // Actualizar tarjetas
        document.getElementById("totalProductos").textContent =
            productos.count ?? 0;

        document.getElementById("totalCategorias").textContent =
            categorias.count ?? 0;

        document.getElementById("totalVentas").textContent =
            ventas.count ?? 0;

        // Identificar productos con bajo inventario
        const productosBajos = listaProductos.data.filter(
            producto => producto.stock <= producto.stock_minimo
        );

        document.getElementById("stockBajo").textContent =
            productosBajos.length;

        // Mostrar productos con poco stock
        if (productosBajos.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="4">No hay productos con bajo inventario.</td>
                </tr>
            `;
            return;
        }

        tabla.innerHTML = productosBajos.map(producto => `
            <tr>
                <td>${escaparHTML(producto.nombre)}</td>
                <td>${escaparHTML(producto.codigo)}</td>
                <td>${producto.stock}</td>
                <td>
                    <span class="estado bajo">Stock bajo</span>
                </td>
            </tr>
        `).join("");

    } catch (error) {
        console.error("Error al cargar el panel:", error);

        tabla.innerHTML = `
            <tr>
                <td colspan="4">
                    No se pudieron cargar los datos. Revisa la conexión con Supabase.
                </td>
            </tr>
        `;
    }
}

function escaparHTML(texto) {
    return String(texto).replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

document.addEventListener("DOMContentLoaded", cargarDashboard);
